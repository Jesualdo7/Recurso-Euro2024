package euro.gestao.dao;

import java.sql.Date;

public class Jogo {
    private Long id;
    private Long casaId;
    private Long foraId;
    private Date data;
    private Long estadioId;
    private int placarCasa;
    private int placarFora;
    private String fase;

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getCasaId() {
        return casaId;
    }

    public void setCasaId(Long casaId) {
        this.casaId = casaId;
    }

    public Long getForaId() {
        return foraId;
    }

    public void setForaId(Long foraId) {
        this.foraId = foraId;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public Long getEstadioId() {
        return estadioId;
    }

    public void setEstadioId(Long estadioId) {
        this.estadioId = estadioId;
    }

    public int getPlacarCasa() {
        return placarCasa;
    }

    public void setPlacarCasa(int placarCasa) {
        this.placarCasa = placarCasa;
    }

    public int getPlacarFora() {
        return placarFora;
    }

    public void setPlacarFora(int placarFora) {
        this.placarFora = placarFora;
    }

    public String getFase() {
        return fase;
    }

    public void setFase(String fase) {
        this.fase = fase;
    }
}

