package euro.gestao.dao;

public class Substituicao {
    private Long id;
    private Long jogoId;
    private Long jogadorEntradaId;
    private Long jogadorSaidaId;
    private int minuto;

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getJogoId() {
        return jogoId;
    }

    public void setJogoId(Long jogoId) {
        this.jogoId = jogoId;
    }

    public Long getJogadorEntradaId() {
        return jogadorEntradaId;
    }

    public void setJogadorEntradaId(Long jogadorEntradaId) {
        this.jogadorEntradaId = jogadorEntradaId;
    }

    public Long getJogadorSaidaId() {
        return jogadorSaidaId;
    }

    public void setJogadorSaidaId(Long jogadorSaidaId) {
        this.jogadorSaidaId = jogadorSaidaId;
    }

    public int getMinuto() {
        return minuto;
    }

    public void setMinuto(int minuto) {
        this.minuto = minuto;
    }
}
