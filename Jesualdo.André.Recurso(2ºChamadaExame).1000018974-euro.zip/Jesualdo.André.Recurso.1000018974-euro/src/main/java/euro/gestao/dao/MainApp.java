package euro.gestao.dao;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import java.util.Scanner;

public class MainApp {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        EuroDAO euroDao = context.getBean(EuroDAO.class);
        Scanner scanner = new Scanner(System.in);
        int opcoesDeJogo = 0;

        do {

            System.out.flush();

            System.out.println("\n\nMenu de Opções");
            System.out.println("1 - Exibir informações de um país organizador");
            System.out.println("2 - Exibir informações de estádios");
            System.out.println("3 - Exibir informações de cidades");
            System.out.println("4 - Exibir calendário e fases de qualificação");
            System.out.println("5 - Exibir informações das equipas");
            System.out.println("6 - Exibir informações dos jogadores");
            System.out.println("7 - Exibir estatísticas dos jogos");
            System.out.println("8 - Exibir informações detalhadas de um jogo");
            System.out.println("9 - Exibir ranking de melhores jogadores do grupo");
            System.out.println("10 - Jogar (Simular resultados de jogos)");
            System.out.println("11 - Marcar Golos (Simular golos de jogadores)");
            System.out.println("12 - Fechar a Aplicação");
            System.out.print("\nEscolha uma opção: ");

            if (scanner.hasNextInt()) {
                opcoesDeJogo = scanner.nextInt();
                scanner.nextLine();
                {
                    switch (opcoesDeJogo) {
                        case 1:
                            System.out.print("Digite o nome do país: ");
                            String pais = scanner.nextLine();
                            euroDao.consultarPais(pais);
                            break;
                        case 2:
                            euroDao.consultarEstadios();
                            break;
                        case 3:
                            euroDao.consultarCidades();
                            break;
                        case 4:
                            euroDao.consultarCalendarioFases();
                            break;
                        case 5:
                            System.out.print("Digite o nome da equipa: ");
                            String equipa = scanner.nextLine();
                            euroDao.consultarEquipa(equipa);
                            break;
                        case 6:
                            System.out.print("Digite o nome do jogador: ");
                            String jogador = scanner.nextLine();
                            euroDao.consultarJogador(jogador);
                            break;
                        case 7:
                            euroDao.consultarEstatisticasJogos();
                            break;
                        case 8:
                            System.out.print("Digite o ID do jogo: ");
                            int jogoId = scanner.nextInt();
                            euroDao.consultarDetalhesJogo(jogoId);
                            break;
                        case 9:
                            euroDao.consultarRankingGrupo();
                            break;
                        case 10:
                            euroDao.simularResultadosJogos();
                            break;
                        case 11:
                            euroDao.marcarGolsAleatorios();
                            break;
                        case 12:
                            System.out.println("Saindo do Sistema...");
                            break;
                        default:
                            System.out.println("Opção inválida!");
                    }
                }
                System.out.print((opcoesDeJogo != 12) ? "Pressione Enter para continuar..." : "");

            }
            else
            {
                System.out.println("Entrada inválida. Digite um número inteiro.");
            }
            if (opcoesDeJogo != 12) {
                scanner.nextLine();
            }
            else {
                System.out.print("");
            }

        } while (opcoesDeJogo != 12);

        scanner.close();
        context.close();
    }
}