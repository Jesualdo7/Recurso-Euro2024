package euro.gestao.dao;

public class EstatisticaJogo {
    private Long id;
    private Long jogoId;
    private Long equipaId;
    private int remates;
    private int livres;
    private int forasDeJogo;

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getJogoId() {
        return jogoId;
    }

    public void setJogoId(Long jogoId) {
        this.jogoId = jogoId;
    }

    public Long getEquipaId() {
        return equipaId;
    }

    public void setEquipaId(Long equipaId) {
        this.equipaId = equipaId;
    }

    public int getRemates() {
        return remates;
    }

    public void setRemates(int remates) {
        this.remates = remates;
    }

    public int getLivres() {
        return livres;
    }

    public void setLivres(int livres) {
        this.livres = livres;
    }

    public int getForasDeJogo() {
        return forasDeJogo;
    }

    public void setForasDeJogo(int forasDeJogo) {
        this.forasDeJogo = forasDeJogo;
    }
}
