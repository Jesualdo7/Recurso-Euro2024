package euro.gestao.dao;

public class Jogador {
    private Long id;
    private String nome;
    private Long equipaId;
    private Long totalGolos;

    // Getters e Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Long getEquipaId() {
        return equipaId;
    }

    public void setEquipaId(Long equipaId) {
        this.equipaId = equipaId;
    }

    public Long getTotalGolos() {
        return totalGolos;
    }

    public void setTotalGolos(Long totalGols) {
        this.totalGolos = totalGols;
    }
}

